package application.views;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.controlsfx.control.table.TableFilter;
import org.controlsfx.control.textfield.TextFields;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
//import org.w3c.dom.Element;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

import application.Main;
import application.support.Application;
import application.support.ObjectProperty;
import application.support.ObjectRepositoryData;
import application.support.Page;
import application.support.XML_Reader;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.FileChooser;

/**
 * Main controller class for the application
 *
 */
public class MainViewController {

	@FXML
	private TableView<ObjectRepositoryData> orTable;
	@FXML
	private TableColumn<ObjectRepositoryData, String> objectName;
	@FXML
	private TableColumn<ObjectRepositoryData, String> locatorType;
	@FXML
	private TableColumn<ObjectRepositoryData, String> objectProperties;
	@FXML
	private Label rightStatusText;
	@FXML
	private Label leftStatusText;
	@FXML
	private TextField applicationNameInput;
	@FXML
	private TextField pageNameInput;
	@FXML
	private TextField objectNameInput;
	@FXML
	private ComboBox<String> locatorTypeCombo;
	@FXML
	private TextField objectPropertyInput;
	@FXML
	private Button addEditButton;
	@FXML
	private Button clearButton;
	@FXML
	private Button deleteButton;

	public static String xmlPath = "";
	private ObservableList<ObjectRepositoryData> masterData = FXCollections.observableArrayList();
	List<Application> appList = new ArrayList<>();

	@FXML
	void initialize() {
		objectName.setCellValueFactory(new PropertyValueFactory<ObjectRepositoryData, String>("objectName"));
		locatorType.setCellValueFactory(new PropertyValueFactory<ObjectRepositoryData, String>("locatorType"));
		objectProperties.setCellValueFactory(new PropertyValueFactory<ObjectRepositoryData, String>("objectProperties"));

		setLocatorTypes();
		loadDataFromXML();
		setTableFilter();

		applicationNameInput.textProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue<? extends String> observable, String oldValue,
					String newValue) {
				if (newValue.split("\\.").length > 0 || newValue.contains(".")) {
					applicationNameInput.setText(newValue.replaceAll("[.]", ""));
				}
			}
		});

		pageNameInput.textProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue<? extends String> observable, String oldValue,
					String newValue) {
				if (newValue.split("\\.").length > 0 || newValue.contains(".")) {
					pageNameInput.setText(newValue.replaceAll("[.]", ""));
				}
			}
		});

		objectNameInput.textProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue<? extends String> observable, String oldValue,
					String newValue) {
				if (newValue.split("\\.").length > 0 || newValue.contains(".")) {
					objectNameInput.setText(newValue.replaceAll("[.]", ""));
				}
			}
		});

	}

	void setRightStatus(String text) {
		rightStatusText.setText(text);
	}

	/**
	 * Clear all the input fields
	 */
	@FXML
	void clearInputs() {
		applicationNameInput.clear();
		pageNameInput.clear();
		objectNameInput.clear();
		locatorTypeCombo.getSelectionModel().clearSelection();
		objectPropertyInput.clear();
	}

	/**
	 * Load data from the XML to display the content in the table
	 */
	void loadDataFromXML() {

		File file = new File(xmlPath);
		if (file != null && file.canRead()) {
			try {
				XML_Reader xmlReader = new XML_Reader(xmlPath);

				String objectName;
				String locatorType;
				String objectProperties;

				NodeList nodeList = xmlReader.getNodeListFromXPATH("//Object");

				for (int i = 0; i < nodeList.getLength(); i++) {

					Node node = nodeList.item(i);
					org.w3c.dom.Element element = (org.w3c.dom.Element) node;

					objectName = nodeList.item(i).getTextContent();
					locatorType = element.getAttribute("locatorType");
					objectProperties = element.getAttribute("property");

					masterData.add(new ObjectRepositoryData(objectName, locatorType, objectProperties));
				}
				orTable.setItems(masterData);
				displayObjectCount();
				Main.primaryStage.setTitle(Main.appTitle+" - "+xmlPath);
				setRightStatus("File loaded - "+xmlPath);
			} catch (Exception e) {
				System.out.println("ERROR! --- Unable to load data from XML : "+xmlPath+"\n"+e);
				DialogViewController.showExceptionDialog("ERROR! --- Unable to load data from XML : "+xmlPath, e);
				setRightStatus("File was not loaded - "+xmlPath);
			}
		}
		else {
			setRightStatus("File was not loaded - "+xmlPath);
		}
	}

	//void createN

	/**	Generates the XML file from the "Application" class object
	 * @param appList
	 * @param fileName
	 */
	void prepareXMLTemplate(List<Application> appList, String fileName) {

		Document doc = new Document();
		Element rootElement = new Element("Object_Repository");
		doc.setRootElement(rootElement);
		Element application = null;
		Element pageNode;
		Element object = null;

		for (Application app : appList) {
			application = new Element("Application");
			application.setAttribute("name", app.getApp());

			for (Page p : app.getPage()) {
				pageNode = new Element("Page");
				pageNode.setAttribute("name", p.getPage());
				application.addContent(pageNode);
				for (ObjectProperty o : p.getobjectPropertyList()) {
					object = new Element("Object");
					object.setAttribute("reference", o.getObject());
					object.setAttribute("locatorType", o.getLocator());
					object.setAttribute("property", o.getObjectProperty());
					object.setText(app.getApp() + "." + p.getPage() + "."
							+ o.getObject());
					pageNode.addContent(object);
				}
			}
			doc.getRootElement().addContent(application);
		}

		XMLOutputter xmlOutputter = new XMLOutputter(Format.getPrettyFormat());
		try {
			new File(fileName).delete(); // Need to erase the content using XML parser
			xmlOutputter.output(doc, new FileOutputStream(fileName));
			setRightStatus("Object repository is saved to - "+fileName);
		} catch (IOException e) {
			System.out.println("ERROR! --- Unbale to write into XML : "+fileName+"\n"+e);
			DialogViewController.showExceptionDialog("ERROR! --- Unable to write data to XML : "+fileName, e);
		}
	}

	/**
	 * Set Table Filter
	 */
	void setTableFilter() {
		TableFilter.forTableView(orTable).lazy(false).apply();
	}

	/**
	 * Set values to the locator type combo box
	 */
	void setLocatorTypes() {
		locatorTypeCombo.getItems().addAll( "id", "name", "cssSelector", "linkText",
				"partialLinkText", "tagName", "xpath");
	}

	/**
	 * Creates a list of "Application" class object from the Object Repository table
	 */
	void getTableData() {

		int nRow = orTable.getItems().size();
		String app;
		String page;
		String locator;
		String objectName;
		String objectProperty;

		for (int rowIndex = 0; rowIndex < nRow; rowIndex++) {

			app = orTable.getItems().get(rowIndex).getObjectName().split("\\.")[0];
			page = orTable.getItems().get(rowIndex).getObjectName().split("\\.")[1];
			objectName = orTable.getItems().get(rowIndex).getObjectName().split("\\.")[2];
			locator = orTable.getItems().get(rowIndex).getLocatorType();
			objectProperty = orTable.getItems().get(rowIndex).getObjectProperties();

			boolean appFlag = false;
			for (Application application : appList) {
				appFlag = false;
				if (application.getApp().equals(app)) {
					application.setPage(page, locator, objectName,
							objectProperty);
					appFlag = true;
					break;
				}
			}

			if (!appFlag) {
				Application application = new Application();
				application.setApp(app);
				application.setPage(page, locator, objectName, objectProperty);
				appList.add(application);
			}
		}
	}

	@FXML
	void createNew() {
		System.out.println("Create a new OR");
	}

	@FXML
	void openFile() {
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Open GTAF Object Repository");
		fileChooser.setInitialDirectory(new File(System.getProperty("user.home")));
		FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("GTAF OR file (*.xml)", "*.xml");
		fileChooser.getExtensionFilters().add(extFilter);
		File selectedFile = fileChooser.showOpenDialog(Main.primaryStage);
		if (selectedFile != null) {
			xmlPath = selectedFile.getAbsolutePath();
			Main.primaryStage.setTitle(Main.appTitle+" - "+xmlPath);
			setRightStatus("File selected - "+xmlPath);
			clearObjectRepositoryTable();
			loadDataFromXML();
		}
		else {
			setRightStatus("File selection canceled");
		}
	}

	/**
	 * Clear all the data in the Object Repository table
	 */
	void clearObjectRepositoryTable() {
		masterData.clear();
		orTable.refresh();
	}

	/**
	 * Closes the application
	 */
	@FXML
	void closeApp() {
		Platform.exit();
	}

	/**
	 * Display the count of rows in the left status bar
	 */
	void displayObjectCount() {
		leftStatusText.setText("Total Objects : "+orTable.getItems().size());
	}

	/**
	 * Add or Edit an object to the Object Repository table
	 */
	@FXML
	void addEditObject() {

		String objectName = applicationNameInput.getText().trim()+"."
				+pageNameInput.getText().trim()+"."
				+objectNameInput.getText().trim();
		String locatorType = locatorTypeCombo.getSelectionModel().getSelectedItem();
		String objectProperty = objectPropertyInput.getText().trim();
		ObjectRepositoryData object = null;
		boolean isFound = false;

		if (applicationNameInput.getText().trim().isEmpty() ||
				pageNameInput.getText().trim().isEmpty() ||
				objectNameInput.getText().trim().isEmpty() ||
				locatorType.isEmpty() ||
				objectProperty.isEmpty()) {

			DialogViewController.showAlert("Invalid input", "Input can not be blank !", "Please provide correct input.");
		}
		else {
			for (int i = 0; i < orTable.getItems().size(); i++) {
				if (orTable.getItems().get(i).getObjectName().equalsIgnoreCase(objectName)) {
					isFound = true;
					object = orTable.getItems().get(i);
					break;
				}
			}
			if (isFound) {
				Optional<ButtonType> option = DialogViewController.showConfirmation("Overwrite Object", "Are you sure want to overwrite this object ?", objectName);
				if (option.get() == ButtonType.OK) {
					masterData.remove(object);
					masterData.add(new ObjectRepositoryData(objectName, locatorType, objectProperty));
					setRightStatus("Object overwritten - "+objectName);
				}
			}
			else {
				masterData.add(new ObjectRepositoryData(objectName, locatorType, objectProperty));
				setRightStatus("Object created - "+objectName);
			}
			orTable.setItems(masterData);
		}
		displayObjectCount();
	}

	/**
	 * Deletes selected row from the Object Repository table
	 */
	@FXML
	void deleteObject() {
		ObjectRepositoryData object = orTable.getSelectionModel().getSelectedItem();
		if (object != null) {
			Optional<ButtonType> option = DialogViewController.showConfirmation("Delete Object", "Are you sure want to delete this object ?", object.getObjectName());
			if (option.get() == ButtonType.OK) {
				masterData.remove(object);
				displayObjectCount();
				setRightStatus("Object deleted - "+object.getObjectName()+orTable.getItems().size());
			}
		}
	}

	/**
	 * Save the Object Repository table data to the loaded XML file
	 */
	@FXML
	void save() {
		if (!xmlPath.equalsIgnoreCase("")) {
			getTableData();
			prepareXMLTemplate(appList, xmlPath);
		}
		else {
			DialogViewController.showAlert("File is not loaded", "No file is found to save.", "Please create/load a file at first to save.");
		}
	}

	/**
	 * Save the Object Repository table data to a new XML file
	 */
	@FXML
	void saveAs() {

		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Save as GTAF Object Repository");
		fileChooser.setInitialDirectory(new File(System.getProperty("user.home")));
		FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("GTAF OR file (*.xml)", "*.xml");
		fileChooser.getExtensionFilters().add(extFilter);
		File selectedFile = fileChooser.showSaveDialog(Main.primaryStage);
		if (selectedFile != null) {
			xmlPath = selectedFile.getAbsolutePath();
			Main.primaryStage.setTitle(Main.appTitle+" - "+xmlPath);
			setRightStatus("File selected - "+xmlPath);
			getTableData();
			prepareXMLTemplate(appList, xmlPath);
		}
		else {
			setRightStatus("File selection canceled");
		}
	}

	/**
	 * Set values to the input fields on selection of Object Repository table row
	 */
	@FXML
	void setInputFieldsOnRowSelect() {
		deleteButton.setDisable(false);
		int selectedRowIndex = orTable.getSelectionModel().getSelectedIndex();
		if (selectedRowIndex >= 0) {
			String app = orTable.getItems().get(selectedRowIndex).getObjectName().split("\\.")[0];
			String page = orTable.getItems().get(selectedRowIndex).getObjectName().split("\\.")[1];
			String objectName = orTable.getItems().get(selectedRowIndex).getObjectName().split("\\.")[2];
			String locator = orTable.getItems().get(selectedRowIndex).getLocatorType();
			String objectProperty = orTable.getItems().get(selectedRowIndex).getObjectProperties();
			applicationNameInput.setText(app);
			pageNameInput.setText(page);
			objectNameInput.setText(objectName);
			locatorTypeCombo.getSelectionModel().select(locator);
			objectPropertyInput.setText(objectProperty);
		}
	}

	/**
	 * Creates auto completion binding for Application Name input
	 */
	@FXML
	void autoPopulateApplicationList() {
		Set<String> data = new HashSet<String>();
		for (int i = 0; i < masterData.size(); i++) {
			data.add(masterData.get(i).getObjectName().split("\\.")[0]);
		}
		TextFields.bindAutoCompletion(applicationNameInput, data);
	}

	/**
	 * Creates auto completion binding for Page Name input
	 */
	@FXML
	void autoPopulatePageList() {
		Set<String> data = new HashSet<String>();
		for (int i = 0; i < masterData.size(); i++) {
			data.add(masterData.get(i).getObjectName().split("\\.")[1]);
		}
		TextFields.bindAutoCompletion(pageNameInput, data);
	}

	/**
	 * Creates auto completion binding for Object Name input
	 */
	@FXML
	void autoPopulateObjectList() {
		Set<String> data = new HashSet<String>();
		for (int i = 0; i < masterData.size(); i++) {
			data.add(masterData.get(i).getObjectName().split("\\.")[2]);
		}
		TextFields.bindAutoCompletion(objectNameInput, data);
	}

}