package application.views;

import application.support.MergedObjectRepositoryData;
import application.support.ObjectRepositoryData;
import application.support.XML_Reader;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import application.Main;
import application.support.ComboBoxCell;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;

public class MergerViewController {


	String xmlPath1 = "C:\\Users\\Arpo\\Desktop\\File1.xml";
	String xmlPath2 = "C:\\Users\\Arpo\\Desktop\\File2.xml";
	String mergedXMLPath = "";

	@FXML
	private Button merge;
	@FXML
	private TableView<MergedObjectRepositoryData> orMergerTable;
	@FXML
	private TableColumn<MergedObjectRepositoryData, String> type;
	@FXML
	private TableColumn<MergedObjectRepositoryData, String> objectName;
	@FXML
	private TableColumn<MergedObjectRepositoryData, String> locatorType;
	@FXML
	private TableColumn<MergedObjectRepositoryData, String> objectProperty;

	private ObservableList<ObjectRepositoryData> xmlData1 = FXCollections.observableArrayList();
	private ObservableList<ObjectRepositoryData> xmlData2 = FXCollections.observableArrayList();
	private ObservableList<MergedObjectRepositoryData> tempMergedData = FXCollections.observableArrayList();
	private ObservableList<MergedObjectRepositoryData> mergedData = FXCollections.observableArrayList();

	private ObservableList<String> duplicateLocator = FXCollections.observableArrayList();
	private ObservableList<String> duplicateObjectProperties = FXCollections.observableArrayList();

	@FXML
	void initialize() {



		type.setCellValueFactory(new PropertyValueFactory<MergedObjectRepositoryData, String>("type"));
		objectName.setCellValueFactory(new PropertyValueFactory<MergedObjectRepositoryData, String>("objectName"));
		locatorType.setCellValueFactory(new PropertyValueFactory<MergedObjectRepositoryData, String>("locatorType"));
		objectProperty.setCellValueFactory(new PropertyValueFactory<MergedObjectRepositoryData, String>("objectProperty"));

		orMergerTable.setEditable(true);

		//mergedData.add(new MergedObjectRepositoryData("Base", "A.B.C", "id", "abcd", FXCollections.observableArrayList("id","name"), FXCollections.observableArrayList("abcd", "bcda")));
		//mergedData.add(new MergedObjectRepositoryData("Other", "X.Y.Z", "name", "ijkl", FXCollections.observableArrayList("cssSelector","name"), FXCollections.observableArrayList("ijkl", "lkji")));
		//mergedData.add(new MergedObjectRepositoryData("Duplicate", "C.Y.Z", "xpath", "xxxx", FXCollections.observableArrayList("id","xpath"), FXCollections.observableArrayList("xxxx", "yyyy")));

		Callback<TableColumn<MergedObjectRepositoryData, String>, TableCell<MergedObjectRepositoryData, String>> cellFactoryLocatorType
			= new Callback<TableColumn<MergedObjectRepositoryData, String>, TableCell<MergedObjectRepositoryData, String>>()
		{
			@Override
			public TableCell<MergedObjectRepositoryData, String> call(final TableColumn<MergedObjectRepositoryData, String> param)
			{
				return new ComboBoxCell(locatorType);
			}
		};

		Callback<TableColumn<MergedObjectRepositoryData, String>, TableCell<MergedObjectRepositoryData, String>> cellFactoryObjectProperty
			= new Callback<TableColumn<MergedObjectRepositoryData, String>, TableCell<MergedObjectRepositoryData, String>>()
	    {
	        @Override
	        public TableCell<MergedObjectRepositoryData, String> call(final TableColumn<MergedObjectRepositoryData, String> param)
	        {
	        	return new ComboBoxCell(objectProperty);
	        }
	    };
	    locatorType.setCellFactory( cellFactoryLocatorType );
	    objectProperty.setCellFactory( cellFactoryObjectProperty );

		//orMergerTable.setItems(mergedData);

	}

	/**
	 * Load data from the XML to display the content in the table
	 */
	void loadDataFromXML(String xmlPath, ObservableList<ObjectRepositoryData> xmlData) {

		File file = new File(xmlPath);
		if (file != null && file.canRead()) {
			try {
				XML_Reader xmlReader = new XML_Reader(xmlPath);

				String objectName;
				String locatorType;
				String objectProperties;

				NodeList nodeList = xmlReader.getNodeListFromXPATH("//Object");

				for (int i = 0; i < nodeList.getLength(); i++) {

					Node node = nodeList.item(i);
					org.w3c.dom.Element element = (org.w3c.dom.Element) node;

					objectName = nodeList.item(i).getTextContent();
					locatorType = element.getAttribute("locatorType");
					objectProperties = element.getAttribute("property");

					xmlData.add(new ObjectRepositoryData(objectName, locatorType, objectProperties));
				}
				/*orTable.setItems(masterData);
				displayObjectCount();
				Main.primaryStage.setTitle(Main.appTitle+" - "+xmlPath);
				setRightStatus("File loaded - "+xmlPath);*/
			} catch (Exception e) {
				System.out.println("ERROR! --- Unable to load data from XML : "+xmlPath+"\n"+e);
				DialogViewController.showExceptionDialog("ERROR! --- Unable to load data from XML : "+xmlPath, e);
				//setRightStatus("File was not loaded - "+xmlPath);
			}
		}
		else {
			//setRightStatus("File was not loaded - "+xmlPath);
		}
	}

	@FXML
	void mergeData() {

		loadDataFromXML(xmlPath1, xmlData1);
		loadDataFromXML(xmlPath2, xmlData2);

		for (int i = 0; i < xmlData2.size(); i++) {

			String objectName = xmlData2.get(i).getObjectName();
			String locatorType = xmlData2.get(i).getLocatorType();
			String objectProperty = xmlData2.get(i).getObjectProperties();

			mergedData.add(new MergedObjectRepositoryData("File2", objectName, locatorType, objectProperty,
					FXCollections.observableArrayList(locatorType), FXCollections.observableArrayList(objectProperty)));
		}

		//tempMergedData.addAll(mergedData);
		int size = mergedData.size();
		for (int i = 0; i < size; i++) {

			String data2ObjectName = mergedData.get(i).getObjectName();
			String data2LocatorType = mergedData.get(i).getLocatorType();
			String data2ObjectProperties = mergedData.get(i).getObjectProperty();
			boolean isFound = false;

			for (ObjectRepositoryData orData1 : xmlData1) {
				if(data2ObjectName.equalsIgnoreCase(orData1.getObjectName())) {
					isFound = true;
					break;
				}
			}
			if(!isFound) {
				mergedData.add(new MergedObjectRepositoryData("File2", data2ObjectName, data2LocatorType, data2ObjectProperties,
						FXCollections.observableArrayList(data2ObjectProperties), FXCollections.observableArrayList(data2ObjectProperties)));
			}
			else {
				System.out.println(data2ObjectName);
				//mergedData.set(i, new MergedObjectRepositoryData("Duplicate", data2ObjectName, data2LocatorType, data2ObjectProperties,
						//FXCollections.observableArrayList(data2ObjectProperties), FXCollections.observableArrayList(data2ObjectProperties)));
			}
		}

		orMergerTable.setItems(mergedData);
	}

}
