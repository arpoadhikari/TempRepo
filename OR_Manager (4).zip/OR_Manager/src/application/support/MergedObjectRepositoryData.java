package application.support;

import javafx.collections.ObservableList;

public class MergedObjectRepositoryData {

	private String type;
	private String objectName;
	private String locatorType;
	private String objectProperty;
	private ObservableList<String> locatorTypeCombo;
	private ObservableList<String> objectPropertyCombo;

	public MergedObjectRepositoryData(String type, String objectName, String locatorType, String objectProperty,
			ObservableList<String> locatorTypeCombo, ObservableList<String> objectPropertyCombo) {
		this.type = type;
		this.objectName = objectName;
		this.locatorType = locatorType;
		this.objectProperty = objectProperty;
		this.locatorTypeCombo = locatorTypeCombo;
		this.objectPropertyCombo = objectPropertyCombo;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getObjectName() {
		return objectName;
	}

	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}

	public String getLocatorType() {
		return locatorType;
	}

	public void setLocatorType(String locatorType) {
		this.locatorType = locatorType;
	}

	public String getObjectProperty() {
		return objectProperty;
	}

	public void setObjectProperty(String objectProperty) {
		this.objectProperty = objectProperty;
	}

	public ObservableList<String> getLocatorTypeCombo() {
		return locatorTypeCombo;
	}

	public void setLocatorTypeCombo(ObservableList<String> locatorTypeCombo) {
		this.locatorTypeCombo = locatorTypeCombo;
	}

	public ObservableList<String> getObjectPropertyCombo() {
		return objectPropertyCombo;
	}

	public void setObjectPropertyCombo(ObservableList<String> objectPropertyCombo) {
		this.objectPropertyCombo = objectPropertyCombo;
	}

}
