package application.views;

import application.support.ObjectRepository;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class MainViewController {

	@FXML
	private TableView<ObjectRepository> personTable;
	@FXML
	private TableColumn<ObjectRepository, String> applicationName;
	@FXML
	private TableColumn<ObjectRepository, String> pageName;
	@FXML
	private TableColumn<ObjectRepository, String> objectName;
	@FXML
	private TableColumn<ObjectRepository, String> locator;
	@FXML
	private TableColumn<ObjectRepository, String> properties;

	private ObservableList<ObjectRepository> masterData = FXCollections.observableArrayList(
			new ObjectRepository("dfd", "ddf", "gffg", "fggffg", "ddg"),
			new ObjectRepository("dsfd", "dsdf", "gfffg", "fgfgffg", "ddfg")
			);

	@FXML
    void initialize() {
		applicationName.setCellValueFactory(new PropertyValueFactory<ObjectRepository, String>("applicationName"));
		pageName.setCellValueFactory(new PropertyValueFactory<ObjectRepository, String>("pageName"));
		objectName.setCellValueFactory(new PropertyValueFactory<ObjectRepository, String>("objectName"));
		locator.setCellValueFactory(new PropertyValueFactory<ObjectRepository, String>("locator"));
		properties.setCellValueFactory(new PropertyValueFactory<ObjectRepository, String>("properties"));
		personTable.setItems(masterData);
	}


}
