package application.support;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class ObjectRepository {

	private String applicationName;
	private String pageName;
	private String objectName;
	private String locator;
	private String properties;

	public ObjectRepository(String applicationName, String pageName, String objectName, String locator,
			String properties) {
		this.applicationName = applicationName;
		this.pageName = pageName;
		this.objectName = objectName;
		this.locator = locator;
		this.properties = properties;
	}

	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	public String getPageName() {
		return pageName;
	}

	public void setPageName(String pageName) {
		this.pageName = pageName;
	}

	public String getObjectName() {
		return objectName;
	}

	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}

	public String getLocator() {
		return locator;
	}

	public void setLocator(String locator) {
		this.locator = locator;
	}

	public String getProperties() {
		return properties;
	}

	public void setProperties(String properties) {
		this.properties = properties;
	}


}
